#!/bin/bash

# Configuration
REPO="tuilakhoa/PhimTop1-CMS"
TOKEN="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"

echo "==== PHIMTOP1-CMS AUTO RELEASE TOOL ===="

# Ensure we are in the right directory
if [ ! -f "config/update.php" ]; then
    echo "Lỗi: Không tìm thấy config/update.php. Vui lòng chạy script này ở thư mục gốc."
    exit 1
fi

echo "Kiểm tra phiên bản hiện tại..."
CURRENT_VERSION=$(grep -oP "'current_version'\s*=>\s*'\K[^']+" config/update.php)

if [ -z "$CURRENT_VERSION" ]; then
    echo "Không tìm thấy current_version. Đặt mặc định là 1.0.0"
    CURRENT_VERSION="1.0.0"
fi

echo "Phiên bản hiện tại: v$CURRENT_VERSION"

# Increment patch version or use argument
if [ -n "$1" ]; then
    NEW_VERSION="$1"
else
    IFS='.' read -ra ADDR <<< "$CURRENT_VERSION"
    MAJOR=${ADDR[0]}
    MINOR=${ADDR[1]}
    PATCH=${ADDR[2]}
    
    NEW_PATCH=$((PATCH + 1))
    NEW_MINOR=$MINOR
    NEW_MAJOR=$MAJOR
    
    if [ "$NEW_PATCH" -gt 99 ]; then
        NEW_PATCH=0
        NEW_MINOR=$((MINOR + 1))
    fi
    
    if [ "$NEW_MINOR" -gt 99 ]; then
        NEW_MINOR=0
        NEW_MAJOR=$((MAJOR + 1))
    fi
    
    NEW_VERSION="$NEW_MAJOR.$NEW_MINOR.$NEW_PATCH"
fi

echo "Phiên bản mới sẽ là: v$NEW_VERSION"

# Update config/update.php
sed -i "s/'current_version' => '$CURRENT_VERSION'/'current_version' => '$NEW_VERSION'/" config/update.php

# Update setup.php
sed -i "s/cmsVersion VARCHAR(50) DEFAULT '$CURRENT_VERSION'/cmsVersion VARCHAR(50) DEFAULT '$NEW_VERSION'/" setup.php
sed -i "s/'$CURRENT_VERSION', 'PhimTop1'/'$NEW_VERSION', 'PhimTop1'/" setup.php

# Update includes/db.php
sed -i "s/'cmsVersion' => '$CURRENT_VERSION'/'cmsVersion' => '$NEW_VERSION'/" includes/db.php

echo "Đã cập nhật mã nguồn lên v$NEW_VERSION."

echo "Nhập nội dung thay đổi cho bản cập nhật này (Enter để dùng mặc định):"
read RELEASE_NOTES
if [ -z "$RELEASE_NOTES" ]; then
    RELEASE_NOTES="Cập nhật hệ thống và tối ưu hoá."
fi

# Git Commit and Push
echo "Đang đẩy code lên Github..."
git add .
git commit -m "Phát hành v$NEW_VERSION" -m "$RELEASE_NOTES"
git push origin main

if [ $? -ne 0 ]; then
    echo "Lỗi khi đẩy code (git push). Vui lòng kiểm tra kết nối mạng hoặc token."
    exit 1
fi

# Create Github Release via API
echo "Đang tạo bản Release v$NEW_VERSION trên Github..."
API_URL="https://api.github.com/repos/$REPO/releases"

# Format release notes for JSON
JSON_NOTES=$(echo "$RELEASE_NOTES" | sed 's/"/\\"/g')

generate_post_data() {
  cat <<EOF
{
  "tag_name": "v$NEW_VERSION",
  "target_commitish": "main",
  "name": "v$NEW_VERSION",
  "body": "✨ Bản cập nhật v$NEW_VERSION\n\n- $JSON_NOTES\n\n- Vui lòng vào Admin > Cập Nhật Hệ Thống để tải bản vá này.",
  "draft": false,
  "prerelease": false
}
EOF
}

# Make the POST request and capture the HTTP status code
RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" -X POST $API_URL \
  -H "Authorization: token $TOKEN" \
  -H "Accept: application/vnd.github.v3+json" \
  -H "Content-Type: application/json" \
  -d "$(generate_post_data)")

if [ "$RESPONSE" -eq 201 ]; then
    echo "HOÀN TẤT! Bản cập nhật v$NEW_VERSION đã được kích hoạt."
    echo "Bây giờ người dùng có thể thấy thông báo cập nhật trong bảng quản trị CMS."
else
    echo "Lỗi khi tạo Release. Mã HTTP: $RESPONSE"
    # Show the actual error message
    curl -s -X POST $API_URL -H "Authorization: token $TOKEN" -H "Accept: application/vnd.github.v3+json" -d "$(generate_post_data)"
    exit 1
fi
