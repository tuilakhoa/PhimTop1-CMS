<?php
require_once __DIR__ . '/includes/db.php';

echo "<h1>Debug Info</h1>";

echo "<h2>1. config.json check</h2>";
$dbConfigPath = __DIR__ . '/config.json';
if (file_exists($dbConfigPath)) {
    echo "<p style='color:green;'>config.json EXISTS!</p>";
    $content = file_get_contents($dbConfigPath);
    echo "<pre>" . htmlspecialchars($content) . "</pre>";
} else {
    echo "<p style='color:red;'>config.json DOES NOT EXIST at " . $dbConfigPath . "</p>";
}

echo "<h2>2. Database connection check</h2>";
$pdo = getPDO();
if ($pdo) {
    echo "<p style='color:green;'>PDO connected successfully!</p>";
    
    echo "<h2>3. Settings check</h2>";
    try {
        $stmt = $pdo->query("SELECT * FROM settings WHERE id = 1");
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            echo "<p style='color:green;'>Settings row found! Admin Path: " . htmlspecialchars($row['adminPath']) . "</p>";
        } else {
            echo "<p style='color:red;'>Settings row NOT FOUND!</p>";
        }
    } catch (Exception $e) {
        echo "<p style='color:red;'>Query failed: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
} else {
    echo "<p style='color:red;'>PDO connection FAILED!</p>";
}

echo "<h2>4. getSettings() check</h2>";
$settings = getSettings();
if ($settings['initialized']) {
    echo "<p style='color:green;'>initialized = TRUE!</p>";
} else {
    echo "<p style='color:red;'>initialized = FALSE!</p>";
}
